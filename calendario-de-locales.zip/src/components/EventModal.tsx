import React, { useState } from 'react';
import { CalendarEvent, Local, GOOGLE_CALENDAR_COLORS, ReminderConfig } from '../types';
import { 
  X, 
  Clock, 
  Calendar as CalendarIcon, 
  Store, 
  MapPin, 
  AlignLeft, 
  Bell, 
  Mail, 
  Users, 
  Plus, 
  Trash2,
  Check
} from 'lucide-react';

interface EventModalProps {
  isOpen: boolean;
  event: Partial<CalendarEvent> | null;
  locales: Local[];
  onClose: () => void;
  onSave: (event: CalendarEvent) => void;
  onDelete?: (id: string) => void;
}

export const EventModal: React.FC<EventModalProps> = ({
  isOpen,
  event,
  locales,
  onClose,
  onSave,
  onDelete,
}) => {
  if (!isOpen || !event) return null;

  const [title, setTitle] = useState(event.title || '');
  const [localId, setLocalId] = useState(event.localId || (locales[0]?.id || ''));
  const [customLocalName, setCustomLocalName] = useState(event.localName || '');
  const [startDate, setStartDate] = useState(
    event.startDate ? event.startDate.substring(0, 16) : '2026-09-14T09:00'
  );
  const [endDate, setEndDate] = useState(
    event.endDate ? event.endDate.substring(0, 16) : '2026-09-14T11:00'
  );
  const [allDay, setAllDay] = useState(event.allDay || false);
  const [colorId, setColorId] = useState(event.colorId || 'peacock');
  const [description, setDescription] = useState(event.description || '');
  const [status, setStatus] = useState<CalendarEvent['status']>(event.status || 'confirmed');
  
  // Attendees
  const [attendees, setAttendees] = useState(event.attendees || [
    { email: 'kevin.zambrano.inteligencia@gmail.com', name: 'Kevin Zambrano', role: 'admin', status: 'accepted' as const }
  ]);
  const [newAttendeeEmail, setNewAttendeeEmail] = useState('');

  // Reminders
  const [reminders, setReminders] = useState<ReminderConfig[]>(event.reminders || [
    { id: 'rem-notif', type: 'notification', minutesBefore: 15 },
    { id: 'rem-email', type: 'email', minutesBefore: 60 }
  ]);

  const selectedColor = GOOGLE_CALENDAR_COLORS.find(c => c.id === colorId) || GOOGLE_CALENDAR_COLORS[0];
  const selectedLocal = locales.find(l => l.id === localId);

  const handleAddAttendee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAttendeeEmail || !newAttendeeEmail.includes('@')) return;
    setAttendees([...attendees, {
      email: newAttendeeEmail.trim(),
      role: 'editor',
      status: 'accepted'
    }]);
    setNewAttendeeEmail('');
  };

  const handleRemoveAttendee = (email: string) => {
    setAttendees(attendees.filter(a => a.email !== email));
  };

  const handleAddReminder = (type: 'email' | 'notification') => {
    setReminders([
      ...reminders,
      {
        id: 'rem-' + Date.now(),
        type,
        minutesBefore: type === 'email' ? 60 : 15,
        sent: false,
      }
    ]);
  };

  const handleRemoveReminder = (id: string) => {
    setReminders(reminders.filter(r => r.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalLocalName = selectedLocal ? selectedLocal.name : (customLocalName || 'Local General');

    const updatedEvent: CalendarEvent = {
      id: event.id || 'evt-' + Date.now(),
      title: title.trim() || `Evento en ${finalLocalName}`,
      description,
      startDate,
      endDate,
      allDay,
      colorId,
      localId: selectedLocal ? selectedLocal.id : 'loc-custom',
      localName: finalLocalName,
      status,
      attendees,
      reminders,
      createdBy: event.createdBy || 'Usuario',
      updatedAt: new Date().toISOString(),
      notes: event.notes || '',
    };

    onSave(updatedEvent);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        id="event-form-modal"
        className="w-full max-w-xl bg-white dark:bg-gray-900 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-800 overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 dark:border-gray-800 bg-gray-50/50 dark:bg-gray-800/40">
          <div className="flex items-center gap-3">
            <span 
              className="w-4 h-4 rounded-full shadow-xs"
              style={{ backgroundColor: selectedColor.bg }}
            />
            <h3 className="font-semibold text-gray-900 dark:text-white text-base">
              {event.id ? 'Editar Evento de Local' : 'Nuevo Evento de Local'}
            </h3>
          </div>
          <button
            type="button"
            id="modal-close-btn"
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 text-sm">
          
          {/* Title input */}
          <div>
            <input
              id="event-title-input"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Añade un título al evento o turno..."
              className="w-full text-lg font-semibold px-3.5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-transparent text-gray-900 dark:text-white placeholder-gray-400 focus:outline-hidden focus:ring-2 focus:ring-blue-500 transition"
              required
            />
          </div>

          {/* Local Selection */}
          <div className="bg-gray-50 dark:bg-gray-800/50 p-3.5 rounded-xl border border-gray-200 dark:border-gray-700 space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-gray-600 dark:text-gray-300 flex items-center gap-1.5">
              <Store className="w-4 h-4 text-blue-500" />
              Seleccionar Local Responsable
            </label>
            <select
              id="event-local-select"
              value={localId}
              onChange={(e) => {
                setLocalId(e.target.value);
                const loc = locales.find(l => l.id === e.target.value);
                if (loc) {
                  setColorId(loc.colorId || colorId);
                }
              }}
              className="w-full px-3 py-2 text-sm rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            >
              {locales.map((loc) => (
                <option key={loc.id} value={loc.id}>
                  {loc.name} ({loc.manager} · {loc.address})
                </option>
              ))}
            </select>
          </div>

          {/* Date and Time Pickers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                Fecha y Hora de Inicio
              </label>
              <input
                id="event-start-date"
                type="datetime-local"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                Fecha y Hora de Fin
              </label>
              <input
                id="event-end-date"
                type="datetime-local"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
          </div>

          {/* Color Category Selector */}
          <div>
            <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-2">
              Categoría y Color Google Calendar
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {GOOGLE_CALENDAR_COLORS.map((col) => (
                <button
                  key={col.id}
                  type="button"
                  onClick={() => setColorId(col.id)}
                  className={`flex items-center gap-2 p-2 rounded-lg border text-left text-xs transition cursor-pointer ${
                    colorId === col.id 
                      ? 'border-blue-500 ring-2 ring-blue-500/20 bg-blue-50/50 dark:bg-blue-900/20 font-semibold' 
                      : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800'
                  }`}
                >
                  <span className="w-3.5 h-3.5 rounded-full shrink-0" style={{ backgroundColor: col.bg }} />
                  <span className="truncate">{col.name.split(' ')[0]}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Status Selector */}
          <div>
            <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1.5">
              Estado de la actividad
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: 'confirmed', label: 'Confirmado' },
                { id: 'in_progress', label: 'En Curso' },
                { id: 'pending', label: 'Pendiente' },
                { id: 'cancelled', label: 'Cancelado' },
              ].map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setStatus(s.id as any)}
                  className={`py-1.5 text-xs rounded-lg border font-medium transition cursor-pointer ${
                    status === s.id
                      ? 'bg-gray-900 text-white dark:bg-white dark:text-gray-900 border-transparent shadow-xs'
                      : 'border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1 flex items-center gap-1.5">
              <AlignLeft className="w-3.5 h-3.5" />
              Descripción y detalles operativos
            </label>
            <textarea
              id="event-description-input"
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Instrucciones para el personal, requerimientos de sala, observaciones..."
              className="w-full px-3 py-2 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Reminders Section (Recordatorios automáticos por correo y notificaciones) */}
          <div className="bg-gray-50 dark:bg-gray-800/40 p-3.5 rounded-xl border border-gray-200 dark:border-gray-700 space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
                <Bell className="w-4 h-4 text-blue-500" />
                Notificaciones y Recordatorios Automáticos
              </label>
              <div className="flex gap-1.5">
                <button
                  type="button"
                  onClick={() => handleAddReminder('notification')}
                  className="px-2 py-1 text-[11px] font-medium rounded-md border border-gray-300 dark:border-gray-600 hover:bg-white dark:hover:bg-gray-700 flex items-center gap-1 transition cursor-pointer"
                >
                  <Plus className="w-3 h-3" /> Notificación
                </button>
                <button
                  type="button"
                  onClick={() => handleAddReminder('email')}
                  className="px-2 py-1 text-[11px] font-medium rounded-md border border-blue-300 dark:border-blue-700 bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 hover:bg-blue-100 flex items-center gap-1 transition cursor-pointer"
                >
                  <Plus className="w-3 h-3" /> Correo
                </button>
              </div>
            </div>

            {reminders.length === 0 ? (
              <p className="text-xs text-gray-500 italic">No hay recordatorios configurados para este evento.</p>
            ) : (
              <div className="space-y-1.5">
                {reminders.map((rem) => (
                  <div key={rem.id} className="flex items-center justify-between gap-2 p-2 rounded-lg bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-xs">
                    <div className="flex items-center gap-2">
                      {rem.type === 'email' ? (
                        <Mail className="w-4 h-4 text-blue-500 shrink-0" />
                      ) : (
                        <Bell className="w-4 h-4 text-amber-500 shrink-0" />
                      )}
                      <span className="font-medium">
                        {rem.type === 'email' ? 'Recordatorio por correo electrónico' : 'Notificación de escritorio / app'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <select
                        value={rem.minutesBefore}
                        onChange={(e) => {
                          const val = Number(e.target.value);
                          setReminders(reminders.map(r => r.id === rem.id ? { ...r, minutesBefore: val } : r));
                        }}
                        className="px-2 py-1 rounded border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 text-xs"
                      >
                        <option value={10}>10 minutos antes</option>
                        <option value={15}>15 minutos antes</option>
                        <option value={30}>30 minutos antes</option>
                        <option value={60}>1 hora antes</option>
                        <option value={120}>2 horas antes</option>
                        <option value={1440}>1 día antes</option>
                      </select>
                      <button
                        type="button"
                        onClick={() => handleRemoveReminder(rem.id)}
                        className="p-1 text-gray-400 hover:text-red-500 transition"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Attendees / Share with other users */}
          <div className="bg-gray-50 dark:bg-gray-800/40 p-3.5 rounded-xl border border-gray-200 dark:border-gray-700 space-y-2.5">
            <label className="text-xs font-bold uppercase tracking-wider text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
              <Users className="w-4 h-4 text-blue-500" />
              Compartir con otros usuarios y colaboradores
            </label>
            <div className="flex gap-2">
              <input
                type="email"
                value={newAttendeeEmail}
                onChange={(e) => setNewAttendeeEmail(e.target.value)}
                placeholder="correo@ejemplo.com"
                className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="button"
                onClick={handleAddAttendee}
                className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-gray-900 text-white dark:bg-white dark:text-gray-900 hover:opacity-90 transition cursor-pointer"
              >
                Añadir
              </button>
            </div>

            <div className="flex flex-wrap gap-1.5 pt-1">
              {attendees.map((att, idx) => (
                <span 
                  key={idx} 
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-xs"
                >
                  <span className="truncate max-w-[160px]">{att.email}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveAttendee(att.email)}
                    className="text-gray-400 hover:text-red-500"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* Modal Actions */}
          <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-800">
            {event.id && onDelete ? (
              <button
                type="button"
                id="modal-delete-btn"
                onClick={() => {
                  if (confirm('¿Seguro que deseas eliminar este evento?')) {
                    onDelete(event.id!);
                    onClose();
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-lg transition cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                Eliminar
              </button>
            ) : <div />}

            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium rounded-lg border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 transition cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                id="save-event-submit-btn"
                className="flex items-center gap-1.5 px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition cursor-pointer"
              >
                <Check className="w-4 h-4" />
                Guardar Evento
              </button>
            </div>
          </div>

        </form>
      </div>
    </div>
  );
};
