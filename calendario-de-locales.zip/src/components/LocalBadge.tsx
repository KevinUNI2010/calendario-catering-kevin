import React from 'react';
import { CalendarEvent, GOOGLE_CALENDAR_COLORS } from '../types';
import { formatTimeHM } from '../utils/dateUtils';
import { Store, Clock, MapPin, AlertCircle } from 'lucide-react';

interface LocalBadgeProps {
  event: CalendarEvent;
  onClick: (e: React.MouseEvent, event: CalendarEvent) => void;
  compact?: boolean;
}

export const LocalBadge: React.FC<LocalBadgeProps> = ({ event, onClick, compact = false }) => {
  const colorDef = GOOGLE_CALENDAR_COLORS.find((c) => c.id === event.colorId) || GOOGLE_CALENDAR_COLORS[0];

  const getStatusDot = (status: CalendarEvent['status']) => {
    switch (status) {
      case 'in_progress':
        return 'bg-emerald-400 animate-pulse';
      case 'confirmed':
        return 'bg-blue-400';
      case 'pending':
        return 'bg-amber-400';
      case 'cancelled':
        return 'bg-red-400';
      default:
        return 'bg-emerald-400';
    }
  };

  if (compact) {
    return (
      <button
        id={`local-badge-${event.id}`}
        type="button"
        onClick={(e) => onClick(e, event)}
        className="w-full text-left group flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-medium transition-all shadow-xs hover:shadow-md hover:scale-[1.01] active:scale-[0.99] border cursor-pointer select-none"
        style={{
          backgroundColor: colorDef.bg,
          color: colorDef.text,
          borderColor: colorDef.border,
        }}
        title={`${event.localName} - ${event.title}`}
      >
        <span className={`w-2 h-2 rounded-full shrink-0 border border-white/60 ${getStatusDot(event.status)}`} />
        <span className="font-semibold truncate max-w-[90px] tracking-tight flex items-center gap-1">
          <Store className="w-3 h-3 shrink-0 opacity-80" />
          {event.localName}
        </span>
        <span className="opacity-90 truncate flex-1 hidden sm:inline">
          · {event.title}
        </span>
        <span className="opacity-75 text-[10px] shrink-0 font-mono ml-auto">
          {formatTimeHM(event.startDate)}
        </span>
      </button>
    );
  }

  return (
    <button
      id={`local-badge-${event.id}`}
      type="button"
      onClick={(e) => onClick(e, event)}
      className="w-full text-left group flex flex-col gap-1 p-2 rounded-lg text-xs font-medium transition-all shadow-xs hover:shadow-md hover:ring-2 hover:ring-offset-1 hover:ring-blue-400 dark:hover:ring-offset-gray-900 border cursor-pointer select-none"
      style={{
        backgroundColor: colorDef.bg,
        color: colorDef.text,
        borderColor: colorDef.border,
      }}
    >
      <div className="flex items-center justify-between gap-1 w-full">
        <div className="flex items-center gap-1.5 font-bold truncate">
          <span className={`w-2 h-2 rounded-full shrink-0 border border-white/60 ${getStatusDot(event.status)}`} />
          <Store className="w-3.5 h-3.5 shrink-0 opacity-90" />
          <span className="truncate">{event.localName}</span>
        </div>
        <span className="opacity-85 text-[10px] font-mono px-1 py-0.5 rounded bg-black/15 shrink-0 flex items-center gap-0.5">
          <Clock className="w-2.5 h-2.5" />
          {formatTimeHM(event.startDate)}
        </span>
      </div>

      <div className="text-[11px] font-medium opacity-95 line-clamp-1">
        {event.title}
      </div>

      {event.reminders && event.reminders.length > 0 && (
        <div className="flex items-center gap-1 text-[10px] opacity-80 pt-0.5">
          <AlertCircle className="w-3 h-3" />
          <span>{event.reminders.some(r => r.type === 'email') ? 'Recordatorio por correo' : 'Notificación activa'}</span>
        </div>
      )}
    </button>
  );
};
