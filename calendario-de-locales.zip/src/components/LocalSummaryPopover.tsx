import React, { useState } from 'react';
import { CalendarEvent, Local, GOOGLE_CALENDAR_COLORS } from '../types';
import { formatTimeHM } from '../utils/dateUtils';
import { 
  Store, 
  Clock, 
  MapPin, 
  User, 
  Mail, 
  Phone, 
  Bell, 
  CheckCircle2, 
  X, 
  Edit3, 
  Trash2, 
  Send, 
  ArrowRight,
  Sparkles,
  Users,
  FileText
} from 'lucide-react';

interface LocalSummaryPopoverProps {
  event: CalendarEvent;
  local?: Local;
  onClose: () => void;
  onQuickUpdate: (updated: Partial<CalendarEvent>) => void;
  onOpenFullEdit: (event: CalendarEvent) => void;
  onDelete: (id: string) => void;
  onSendInstantEmail: (event: CalendarEvent) => void;
}

export const LocalSummaryPopover: React.FC<LocalSummaryPopoverProps> = ({
  event,
  local,
  onClose,
  onQuickUpdate,
  onOpenFullEdit,
  onDelete,
  onSendInstantEmail,
}) => {
  const [quickNote, setQuickNote] = useState(event.notes || '');
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const [emailSentNotice, setEmailSentNotice] = useState(false);

  const colorDef = GOOGLE_CALENDAR_COLORS.find((c) => c.id === event.colorId) || GOOGLE_CALENDAR_COLORS[0];

  const handleShiftTime = (minutes: number) => {
    const start = new Date(event.startDate);
    const end = new Date(event.endDate);

    start.setMinutes(start.getMinutes() + minutes);
    end.setMinutes(end.getMinutes() + minutes);

    const pad = (n: number) => String(n).padStart(2, '0');
    const toISO = (d: Date) => 
      `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;

    onQuickUpdate({
      startDate: toISO(start),
      endDate: toISO(end),
    });
  };

  const handleStatusChange = (status: CalendarEvent['status']) => {
    onQuickUpdate({ status });
  };

  const handleColorChange = (colorId: string) => {
    onQuickUpdate({ colorId });
  };

  const handleSaveNote = () => {
    onQuickUpdate({ notes: quickNote });
  };

  const handleSendReminder = async () => {
    setIsSendingEmail(true);
    await onSendInstantEmail(event);
    setIsSendingEmail(false);
    setEmailSentNotice(true);
    setTimeout(() => setEmailSentNotice(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-150">
      <div 
        id="local-summary-dialog"
        className="w-full max-w-lg bg-white dark:bg-gray-900 rounded-2xl shadow-2xl border border-gray-200 dark:border-gray-800 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Color Accent Bar & Header */}
        <div 
          className="p-5 text-white flex items-start justify-between relative transition-colors"
          style={{ backgroundColor: colorDef.bg }}
        >
          <div className="flex-1 pr-4">
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase opacity-90">
              <Store className="w-4 h-4" />
              <span>{event.localName}</span>
              {local?.code && <span className="bg-black/20 px-1.5 py-0.5 rounded text-[10px]">{local.code}</span>}
            </div>
            <h2 className="text-xl font-bold mt-1 text-white tracking-tight leading-snug">
              {event.title}
            </h2>
            <div className="flex items-center gap-2 mt-2 text-xs opacity-95">
              <Clock className="w-3.5 h-3.5" />
              <span>
                {new Date(event.startDate).toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric', month: 'short' })} · {formatTimeHM(event.startDate)} - {formatTimeHM(event.endDate)}
              </span>
            </div>
          </div>
          <button
            id="close-summary-btn"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-black/20 transition text-white/90 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-5 text-gray-800 dark:text-gray-200">
          
          {/* Detailed Summary Card */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-gray-50 dark:bg-gray-800/60 p-3.5 rounded-xl border border-gray-100 dark:border-gray-800">
            {local?.address && (
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-gray-400 dark:text-gray-500 shrink-0 mt-0.5" />
                <div>
                  <span className="font-medium block text-gray-500 dark:text-gray-400">Dirección</span>
                  <span className="font-semibold">{local.address}</span>
                </div>
              </div>
            )}

            {local?.manager && (
              <div className="flex items-start gap-2">
                <User className="w-4 h-4 text-gray-400 dark:text-gray-500 shrink-0 mt-0.5" />
                <div>
                  <span className="font-medium block text-gray-500 dark:text-gray-400">Encargado de Local</span>
                  <span className="font-semibold">{local.manager}</span>
                  {local.phone && <span className="block text-[11px] text-gray-500">{local.phone}</span>}
                </div>
              </div>
            )}

            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-gray-400 dark:text-gray-500 shrink-0 mt-0.5" />
              <div>
                <span className="font-medium block text-gray-500 dark:text-gray-400">Estado del Turno</span>
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold mt-0.5 ${
                  event.status === 'in_progress' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300' :
                  event.status === 'confirmed' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300' :
                  event.status === 'pending' ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300' :
                  'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300'
                }`}>
                  {event.status === 'in_progress' ? 'En curso / Operando' :
                   event.status === 'confirmed' ? 'Confirmado' :
                   event.status === 'pending' ? 'Pendiente de inicio' : 'Cancelado'}
                </span>
              </div>
            </div>

            {local?.capacity && (
              <div className="flex items-start gap-2">
                <Users className="w-4 h-4 text-gray-400 dark:text-gray-500 shrink-0 mt-0.5" />
                <div>
                  <span className="font-medium block text-gray-500 dark:text-gray-400">Capacidad Aforo</span>
                  <span className="font-semibold">{local.capacity} personas</span>
                </div>
              </div>
            )}
          </div>

          {/* Description / Notes if any */}
          {event.description && (
            <div className="text-xs">
              <span className="text-gray-500 dark:text-gray-400 font-medium block mb-1">Descripción del Evento</span>
              <p className="p-2.5 rounded-lg bg-gray-50 dark:bg-gray-800/40 border border-gray-100 dark:border-gray-800 text-gray-700 dark:text-gray-300 leading-relaxed">
                {event.description}
              </p>
            </div>
          )}

          {/* Attendees / Collaborators */}
          {event.attendees && event.attendees.length > 0 && (
            <div className="text-xs">
              <span className="text-gray-500 dark:text-gray-400 font-medium block mb-1 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5" />
                Participantes y Acceso Compartido ({event.attendees.length})
              </span>
              <div className="flex flex-wrap gap-1.5">
                {event.attendees.map((att, idx) => (
                  <span 
                    key={idx} 
                    className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-900 text-[11px]"
                  >
                    <Mail className="w-3 h-3 opacity-70" />
                    {att.email}
                    <span className="text-[9px] opacity-75 font-mono">({att.role})</span>
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* QUICK EDIT OPTIONS (Opciones de edición rápida) */}
          <div className="pt-3 border-t border-gray-200 dark:border-gray-800 space-y-3.5">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-blue-500" />
                Opciones de Edición Rápida
              </h3>
              <span className="text-[10px] text-gray-400">Sincronización en tiempo real</span>
            </div>

            {/* Quick Shift Time */}
            <div>
              <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1.5">
                Ajuste rápido de horario:
              </label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  id="shift-minus-30"
                  onClick={() => handleShiftTime(-30)}
                  className="px-2.5 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 font-medium transition cursor-pointer"
                >
                  -30 min
                </button>
                <button
                  type="button"
                  id="shift-plus-30"
                  onClick={() => handleShiftTime(30)}
                  className="px-2.5 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 font-medium transition cursor-pointer"
                >
                  +30 min
                </button>
                <button
                  type="button"
                  id="shift-plus-60"
                  onClick={() => handleShiftTime(60)}
                  className="px-2.5 py-1 text-xs rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 font-medium transition cursor-pointer"
                >
                  +1 hora
                </button>
              </div>
            </div>

            {/* Quick Status Toggle */}
            <div>
              <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1.5">
                Cambiar estado del local:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                {[
                  { id: 'confirmed', label: 'Confirmado', bg: 'hover:bg-blue-50 dark:hover:bg-blue-900/30' },
                  { id: 'in_progress', label: 'En Curso', bg: 'hover:bg-emerald-50 dark:hover:bg-emerald-900/30' },
                  { id: 'pending', label: 'Pendiente', bg: 'hover:bg-amber-50 dark:hover:bg-amber-900/30' },
                  { id: 'cancelled', label: 'Cancelado', bg: 'hover:bg-red-50 dark:hover:bg-red-900/30' },
                ].map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => handleStatusChange(s.id as any)}
                    className={`px-2 py-1.5 text-xs rounded-lg border font-medium text-center transition cursor-pointer ${
                      event.status === s.id
                        ? 'border-blue-500 bg-blue-500 text-white font-bold'
                        : `border-gray-200 dark:border-gray-700 ${s.bg}`
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Color Categorization */}
            <div>
              <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1.5">
                Color de categoría Google:
              </label>
              <div className="flex flex-wrap gap-2">
                {GOOGLE_CALENDAR_COLORS.slice(0, 8).map((col) => (
                  <button
                    key={col.id}
                    type="button"
                    onClick={() => handleColorChange(col.id)}
                    className={`w-6 h-6 rounded-full transition-transform cursor-pointer border-2 ${
                      event.colorId === col.id ? 'scale-125 border-gray-900 dark:border-white shadow-xs' : 'border-transparent hover:scale-110'
                    }`}
                    style={{ backgroundColor: col.bg }}
                    title={col.name}
                  />
                ))}
              </div>
            </div>

            {/* Quick Note Editor */}
            <div>
              <label className="block text-[11px] font-medium text-gray-500 dark:text-gray-400 mb-1">
                Nota rápida interna:
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={quickNote}
                  onChange={(e) => setQuickNote(e.target.value)}
                  placeholder="Añadir nota rápida (ej. personal adicional, clave de alarma)..."
                  className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="button"
                  onClick={handleSaveNote}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 transition cursor-pointer"
                >
                  Guardar
                </button>
              </div>
            </div>

            {/* Send Instant Email Reminder button */}
            <div className="pt-2">
              <button
                type="button"
                id="send-instant-email-btn"
                onClick={handleSendReminder}
                disabled={isSendingEmail}
                className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 hover:bg-blue-100 dark:hover:bg-blue-900/50 transition cursor-pointer disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                {isSendingEmail ? 'Enviando correo...' : 'Enviar recordatorio por correo ahora'}
              </button>
              {emailSentNotice && (
                <p className="text-[11px] text-emerald-600 dark:text-emerald-400 text-center font-medium mt-1 animate-in fade-in">
                  ✓ Recordatorio por correo electrónico enviado a los participantes
                </p>
              )}
            </div>

          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-gray-50 dark:bg-gray-800/80 border-t border-gray-200 dark:border-gray-800 flex items-center justify-between gap-2">
          <button
            type="button"
            id="delete-event-btn"
            onClick={() => {
              if (confirm(`¿Eliminar evento en ${event.localName}?`)) {
                onDelete(event.id);
                onClose();
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 dark:text-red-400 dark:hover:bg-red-950/40 rounded-lg transition cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Eliminar
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs font-medium rounded-lg border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 transition cursor-pointer"
            >
              Cerrar
            </button>
            <button
              type="button"
              id="open-full-edit-btn"
              onClick={() => {
                onOpenFullEdit(event);
                onClose();
              }}
              className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              Edición Completa
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
